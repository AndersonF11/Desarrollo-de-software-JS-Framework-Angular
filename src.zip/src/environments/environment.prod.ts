export const environment = {
  production: true,
  URL_BACKEND: "http://localhost:3000/v1",
};
